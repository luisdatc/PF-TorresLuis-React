import "./ShipCardSales.scss";

const ShipCardSales = () => {
  return (
    <div className="div-img">
      <img
        src="/public/1.png"
        alt="Ship-Card-Sales"
        className="img-fluid ship-card-sales"
      />
    </div>
  );
};

export default ShipCardSales;
