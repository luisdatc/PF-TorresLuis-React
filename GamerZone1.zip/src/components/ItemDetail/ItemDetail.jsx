
const ItemDetail = () => {
  return (
    <div>ItemDetail</div>
  )
}

export default ItemDetail