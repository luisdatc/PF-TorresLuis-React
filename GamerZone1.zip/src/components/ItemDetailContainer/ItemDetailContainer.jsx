import ItemDetail from '../ItemDetail/ItemDetail'

const ItemDetailContainer = () => {
//estado para guardar un producto
//useeffect para llamar a la api o json para traer un producto y luego guardar en el estado 


  return (
    <div>
        <ItemDetail
        
        //product={product}
        />
    </div>
  )
}

export default ItemDetailContainer